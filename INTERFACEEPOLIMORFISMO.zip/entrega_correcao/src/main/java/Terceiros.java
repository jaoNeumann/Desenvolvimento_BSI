import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Terceiros {
    public int id;
    public String Nome;

    public void salvar() {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionSingleton.getConnection();

            // Verificar se o terceiro já existe
            String selectSql = "SELECT * FROM terceiros WHERE services_providers_id = ?";
            stmt = conn.prepareStatement(selectSql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Terceiro já existe, realizar o update
                String updateSql = "UPDATE terceiros SET providers_name = ? WHERE services_providers_id = ?";
                stmt = conn.prepareStatement(updateSql);
                stmt.setString(1, Nome);
                stmt.setInt(2, id);
                stmt.executeUpdate();
                System.out.println("Terceiro atualizado com sucesso!");
            } else {
                // Terceiro não existe, realizar a inserção
                String insertSql = "INSERT INTO terceiros (services_providers_id, providers_name) VALUES (?, ?)";
                stmt = conn.prepareStatement(insertSql);
                stmt.setInt(1, id);
                stmt.setString(2, Nome);
                stmt.executeUpdate();
                System.out.println("Terceiro salvo com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar o terceiro.");
            e.printStackTrace();
        } finally {
            // Fechar as conexões e recursos
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com o banco de dados.");
                e.printStackTrace();
            }
        }
    }

    public void deletar() {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionSingleton.getConnection();

            String deleteSql = "DELETE FROM terceiros WHERE services_providers_id = ?";
            stmt = conn.prepareStatement(deleteSql);
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Terceiro excluído com sucesso!");
            } else {
                System.out.println("Não foi possível excluir o terceiro. Verifique se o ID está correto.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao deletar o terceiro.");
            e.printStackTrace();
        } finally {
            // Fechar as conexões e recursos
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com o banco de dados.");
                e.printStackTrace();
            }
        }
    }
}
