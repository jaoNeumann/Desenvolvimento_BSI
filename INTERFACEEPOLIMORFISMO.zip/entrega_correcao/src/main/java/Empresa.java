import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Empresa {

	public String cnpj;
	public String Nome;
	public int serviceType;
	public int idTerceiro;
	public Connection conn;
    
    public void salvar() {
        try {
            conn = ConnectionSingleton.getConnection();

            String selectSql = "SELECT * FROM empresa WHERE cnpj = ?";
            PreparedStatement selectStmt = conn.prepareStatement(selectSql);
            selectStmt.setString(1, cnpj);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                // A empresa já existe, realizar o update
                String updateSql = "UPDATE empresa SET fantasy_name = ?, service_type = ?, service_provider_code = ? WHERE cnpj = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setString(1, Nome);
                updateStmt.setInt(2, serviceType);
                updateStmt.setInt(3, idTerceiro);
                updateStmt.setString(4, cnpj);
                updateStmt.executeUpdate();

                System.out.println("Empresa atualizada com sucesso!");
            } else {
                // A empresa não existe, realizar a inserção
                String insertSql = "INSERT INTO empresa (cnpj, fantasy_name, service_type, service_provider_code) VALUES (?, ?, ?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                insertStmt.setString(1, cnpj);
                insertStmt.setString(2, Nome);
                insertStmt.setInt(3, serviceType);
                insertStmt.setInt(4, idTerceiro);
                insertStmt.executeUpdate();

                System.out.println("Empresa salva com sucesso!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
