package heranca;

public class Consumidor_polimorfismo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aluno a = new Aluno();
		Professor p = new Professor();
		Testadora t = new Testadora();
		
		a.nome = "Joao";
		p.nome = "Escobar";
		
		t.processar(a);
		t.processar(p);
		
	}

}
