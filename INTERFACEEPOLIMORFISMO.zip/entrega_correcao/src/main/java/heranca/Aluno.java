package heranca;

public class Aluno extends Pessoa{
	public String situacao_matricula;
	@Override
	public boolean Save() {
		// Aproveitar o comportramento do 'Save()' da SuperClasse
		super.Save();
		System.out.println("Retorno Aluno");
		return true;
	}
}
	
