package heranca;

public abstract class Pessoa {
	public String matricula;
	public String cpf;
	public String nome;
	public String email;
	public int idade;
	
	
	public boolean Save() {
		System.out.println("Salvar() da superclasse: " + this.nome);
		return true;
	}
	public boolean Find_one() {
		System.out.println("Find_one() da superclasse");

		return true;
	}
	public boolean Delete() {
		System.out.println("Delete() da superclasse");
		return true;
	}
	
	
}























