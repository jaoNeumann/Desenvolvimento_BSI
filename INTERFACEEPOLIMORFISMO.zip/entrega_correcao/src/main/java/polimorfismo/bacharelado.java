package polimorfismo;

public class bacharelado implements intercurso{
	public String nome_curso;
	public int carga_horaria;
	public double valor_parcela;
	@Override
	public double GetCusto_do_Curso() {
		// TODO Auto-generated method stub
		return 0;
	}
 	
}
