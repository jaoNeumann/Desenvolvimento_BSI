package polimorfismo;

public class ConsumidorPolimorfismo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pedagio p = new Pedagio();
		CarroPasseio carro = new CarroPasseio();
		Caminhao caminhao = new Caminhao();
		
		carro.eixos = 2;
		caminhao.eixos = 6;
		
		System.out.println(p.Cobrar(caminhao));
		System.out.println(p.Cobrar(carro));

	}

}
