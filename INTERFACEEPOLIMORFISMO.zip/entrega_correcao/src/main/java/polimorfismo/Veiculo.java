package polimorfismo;

public interface Veiculo {
	double getEixos();

}