package polimorfismo;

import java.util.ArrayList;

public class estudante {
	String matricula;
	String nome;
	String cpf;
	String email;
	ArrayList<intercurso> cursos = new ArrayList<intercurso>();
	
}
