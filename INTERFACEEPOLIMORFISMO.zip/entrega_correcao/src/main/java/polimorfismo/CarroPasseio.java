package polimorfismo;

public class CarroPasseio implements Veiculo{

	public String combustivel;
	public int eixos;
	
	
	@Override
	public double getEixos() {
		// TODO Auto-generated method stub
		return this.eixos/2;
	}
	
}
