package polimorfismo;

public interface intercurso {
	// A interface define as assinaturas dos métodos.
	//Não define propriedades.
	double GetCusto_do_Curso();
	
}
