package polimorfismo;

import java.util.ArrayList;

public class consumidor_inter_cursos {
	public static void main(String[] args) {
		ArrayList<intercurso> cursos = new ArrayList<intercurso>();
		// Instanciar um bacharelado
		bacharelado BSI = new bacharelado();
		BSI.nome_curso="BSI";
		BSI.carga_horaria=3600;
		BSI.valor_parcela=1200;
		
		// Instanciar um bacharelado com laboratório
		bacharelado_laboratorio ODONTO = new bacharelado_laboratorio();
		ODONTO.nome_curso="ODONTO";
		ODONTO.carga_horaria=4000;
		ODONTO.valor_parcela=5000;
		ODONTO.custo_lab=1000;
		
		// Adicionar um curso na lista bacharelado
		cursos.add(BSI);
		cursos.add(ODONTO);
		
		
		
		
		
		
		
	}

}