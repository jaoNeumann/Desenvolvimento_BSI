package polimorfismo;

public class Moto {
	
}
