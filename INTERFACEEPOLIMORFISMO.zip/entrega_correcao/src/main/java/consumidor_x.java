public class consumidor_x {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Servicos servico = new Servicos();
		ServicosPrestados servicos_prestados = new ServicosPrestados();
//		Empresa emp = new Empresa();
		servicos_prestados.data = "29/05/23";
		servicos_prestados.valor = 555; 
		servicos_prestados.terceiro.id = 101;
		servicos_prestados.cliente.cpf = "11111111111";
		servicos_prestados.servico.id = 1;		
//		servicos_prestados.id = 6;
		servicos_prestados.salvar();
//		servicos_prestados.deletar();
		
		System.out.println(
			"data da prestação do serviço: " +
			servicos_prestados.data
		);
	
//		servico.nome = "Serviço C";
//		servico.excluir();
	
	}
}