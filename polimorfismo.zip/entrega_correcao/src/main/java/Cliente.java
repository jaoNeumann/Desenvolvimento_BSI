import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Cliente {
    public String nome;
    public String cpf;
    public int idade;
    Connection conn;

    // Método find_one
    public void find_one(String cpf) {
        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String sql = "SELECT * FROM cliente WHERE cpf = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cpf);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                this.cpf = rs.getString("cpf");
                this.nome = rs.getString("name");
                this.idade = rs.getInt("age");
            }

            // Não é necessário fechar a conexão, já que o singleton cuida disso

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método salvar
    public void salvar() {
        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String selectSql = "SELECT * FROM cliente WHERE cpf = ?";
            PreparedStatement selectPs = conn.prepareStatement(selectSql);
            selectPs.setString(1, this.cpf);

            ResultSet rs = selectPs.executeQuery();

            if (rs.next()) {
                // CPF já existe, realizar o update
                String updateSql = "UPDATE cliente SET name = ?, age = ? WHERE cpf = ?";
                PreparedStatement updatePs = conn.prepareStatement(updateSql);
                updatePs.setString(1, this.nome);
                updatePs.setInt(2, this.idade);
                updatePs.setString(3, this.cpf);
                updatePs.executeUpdate();
                System.out.println("Dados atualizados com sucesso!");
            } else {
                // CPF não existe, realizar a inserção
                String insertSql = "INSERT INTO cliente (cpf, name, age) VALUES (?, ?, ?)";
                PreparedStatement insertPs = conn.prepareStatement(insertSql);
                insertPs.setString(1, this.cpf);
                insertPs.setString(2, this.nome);
                insertPs.setInt(3, this.idade);
                insertPs.executeUpdate();
                System.out.println("Usuário salvo com sucesso!");
            }

            // Não é necessário fechar a conexão, já que o singleton cuida disso

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método deletar
    public void deletar() {
        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String sql = "DELETE FROM cliente WHERE cpf = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, this.cpf);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Cliente excluído com sucesso!");
            } else {
                System.out.println("Cliente não encontrado no banco de dados.");
            }

            // Não é necessário fechar a conexão, já que o singleton cuida disso

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	public String getCpf() {
		// TODO Auto-generated method stub
		
		return this.cpf;
	}
}
