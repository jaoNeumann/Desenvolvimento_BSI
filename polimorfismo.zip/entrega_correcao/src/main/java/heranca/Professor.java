package heranca;

public class Professor extends Pessoa{
	public String tipo_contrato;

	@Override
	public boolean Save(){
		// Aproveitar o comportramento do 'Save()' da SuperClasse
		super.Save();
		System.out.println("Retorno Professor");
		return true;
	}
}
