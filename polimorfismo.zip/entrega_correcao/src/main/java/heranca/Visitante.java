package heranca;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Visitante extends Pessoa{
	public String data_visita;
	Date data_atual = new Date(); 
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    String dataFormatada = formato.format(data_atual);

	public boolean Liberar(){
		
		return true;
	}
	@Override
	public boolean Save() {
		super.Save();
		if(data_visita equals.(data_atual)) {
	        System.out.println(dataFormatada); 
		}
		System.out.println("Retorno Visitante");
		return true;
	}
}
