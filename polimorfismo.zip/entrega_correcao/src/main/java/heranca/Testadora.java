package heranca;

public class Testadora {
	public void processar(Aluno a) {
		a.Save();
	}
	
	public void processar(Professor p) {
		p.Save();
	}
}
