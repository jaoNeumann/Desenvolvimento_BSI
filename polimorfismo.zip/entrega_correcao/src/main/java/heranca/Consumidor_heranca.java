package heranca;

public class Consumidor_heranca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aluno a = new Aluno();
		Professor p = new Professor();
		Visitante v = new Visitante();
		
		v.nome = "João";
		v.cpf = "777";
		v.data_da_visita = "01/06/2023";
		
		v.Save();
		
//		p.cpf = "999";
//		p.nome = "Escobar, o belo";
//		p.tipo_contrato = "Horista";
//		p.matricula = "A010203";
		
//		a.cpf = "888";
//		a.nome = "Pedro de Lara";
//		a.situacao_matricula = "Ativa";
//		a.idade = 19;
		
		// METHODS
		//a.Save();
		//p.Save();
		
	}

}
