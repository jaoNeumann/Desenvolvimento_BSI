package polimorfismo;

public class Pedagio {
	private double tarifa;
	
	public double Cobrar(Veiculo v) {
		System.out.println(v.getEixos()*2.5);
		return v.getEixos()*2.5;
	}
	
}
