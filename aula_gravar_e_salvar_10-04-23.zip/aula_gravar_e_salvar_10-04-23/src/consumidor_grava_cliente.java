import java.util.Scanner;

public class consumidor_grava_cliente {
    public static void main(String[] args) {
        String op = "";
        Scanner teclado = new Scanner(System.in);
        cliente_7 cli = new cliente_7();

        while (!op.equals("0")) {
            System.out.println("Digite 0 para terminar");

            System.out.println("Nome");
            cli.nome = teclado.nextLine();
            teclado = new Scanner(System.in);

            System.out.println("CPF");
            cli.cpf = teclado.nextLine();
            teclado = new Scanner(System.in);

            System.out.println("Email");
            cli.email = teclado.nextLine();
            teclado = new Scanner(System.in);

            cli.salvar();
            System.out.println("Deseja continuar? (0 para sair)");
            op = teclado.nextLine();

        }
    }
}
