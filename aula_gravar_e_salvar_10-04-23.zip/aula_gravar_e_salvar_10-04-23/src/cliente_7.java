import java.io.FileWriter;

public class cliente_7 {

    public String cpf;
    public String nome;
    public String email;

    // save method

    public void salvar() {
        try {
            String separador = ";";
            FileWriter arquivo = new FileWriter("C:\\Users\\Aluno\\Documents\\jhon_data\\client.csv", true);
            String linha = this.nome
                    + separador +
                    this.cpf
                    + separador +
                    this.email
                    + System.lineSeparator();

            arquivo.write(linha);
            arquivo.flush();
            arquivo.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    };

}
