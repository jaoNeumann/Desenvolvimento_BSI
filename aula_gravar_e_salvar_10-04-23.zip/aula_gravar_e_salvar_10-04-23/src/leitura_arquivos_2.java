import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class leitura_arquivos_2 {
    public static void main(String[] args) {

        String arquivo = "C:\\Users\\Aluno\\Documents\\jhon_data\\dados.csv";

        try {
            FileInputStream stream = new FileInputStream(arquivo);
            InputStreamReader reader = new InputStreamReader(stream);
            BufferedReader buf_reader = new BufferedReader(reader);
            String linha = buf_reader.readLine();

            while (linha != null) {
                System.out.println(linha);
                linha = buf_reader.readLine();
            }
            // close
            buf_reader.close();
            reader.close();
            stream.close();

        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception

        }
    }
}