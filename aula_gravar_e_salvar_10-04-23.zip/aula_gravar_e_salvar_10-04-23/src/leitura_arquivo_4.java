import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class leitura_arquivo_4 {
    public static void main(String[] args) {
        cliente_7 cli = new cliente_7();
        try {
            FileReader arq_read = new FileReader("C:\\Users\\Aluno\\Documents\\jhon_data\\dados.csv");
            BufferedReader read_this = new BufferedReader(arq_read);
            String leia = read_this.readLine();
            // Dispensar a primeira linha

            leia = read_this.readLine();
            // Ler segunda linha

            cli.nome = leia.split(";")[1];
            cli.email = leia.split(";")[2];
            cli.cpf = leia.split(";")[0];
            // System.out.println(leia.split(";")[2]);

            System.out.println(cli.cpf + " " + cli.nome + " " + cli.email);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
