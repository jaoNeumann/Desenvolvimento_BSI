package exercicioFaculdade;

public class consumidor_professor {
    public static void main(String[] args) {
        Professor p = new Professor("888", "3003", "Escobar", "escobar@email.com");
        System.out.println(p.Nome + " " + p.Email);
    }
}
