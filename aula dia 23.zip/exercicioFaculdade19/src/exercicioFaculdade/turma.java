package exercicioFaculdade;

import java.util.ArrayList;

public class turma {

	public int Codigo;

    public String Curso;

    public Professor prof = new Professor();



    public ArrayList<aluno> Alunos = new ArrayList<aluno>();

    public Professor Professor;



    // public ArrayList<String> busca_aluno() {
    //     ArrayList<String> alunos = new ArrayList<String>();
    //     for(int i = 0; i < this.Alunos.size(); i++)
    //         alunos.add(this.Alunos.get(i).Nome);
    //     return(alunos);
    // }

            
    public ArrayList<String> getAlunos(int pos){
        ArrayList<String> nomes = new ArrayList<String>();
        nomes.add(this.Alunos.get(pos).Nome);
        return nomes;
    }
}
