package gerenciamentoDeContaBancaria;

import java.util.ArrayList;

public class Cliente{

    public ArrayList<Conta> Cliente_contas = new ArrayList<Conta>();
    public String Cpf;
	public String Nome;
	public String Email;

    public Cliente(String Cpf, String Nome, String Email){
		this.Cpf = Cpf;
		this.Nome = Nome;
		this.Email = Email;
        // this.Cliente_contas = Conta();
	}
}