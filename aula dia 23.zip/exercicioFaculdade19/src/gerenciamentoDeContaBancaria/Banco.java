package gerenciamentoDeContaBancaria;

import java.util.ArrayList;

public class Banco{

    public ArrayList<Cliente> Clientes = new ArrayList<Cliente>();

}