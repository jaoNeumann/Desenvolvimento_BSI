package gerenciamentoDeContaBancaria;

public class Consumidor_Banco {
    
    public static void main(String[] args) {
//banco 
        Banco ban = new Banco();    
        Cliente cli = new Cliente("001", "Joao", "Joao@email.com");

        Conta con = new Conta();
        con.Numero = 001;
        con.Tipo = "CC";
        
        System.out.println(cli.);

    }
}
