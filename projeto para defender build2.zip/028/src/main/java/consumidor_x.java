import com.sun.jdi.connect.spi.Connection;

public class consumidor_x {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Servicos servico = new Servicos();
		
//		servico.id = 4;
//		servico.nome = "serviço xxx4"; 
//		servico.salvar();
//		
//		System.out.println("Nome do serviço: " + servico.nome + " | " + "Código do sercviço: " + servico.id);
//	
//		servico.nome = "Serviço C";
//		servico.excluir();
	
	}
}