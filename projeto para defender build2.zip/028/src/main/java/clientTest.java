
public class clientTest{
    public static void main(String[] args) {
        cliente cliente = new cliente();

        // search by cpf
//        cliente.find_one("11111111111");

        //salva
        cliente.cpf = "11111111143";
        cliente.nome = "caio agora";
        cliente.idade = 32;
        cliente.salvar();
        
      System.out.println("CPF: " + cliente.cpf + "| Nome: " + cliente.nome + "| idade: " + cliente.idade);
      //deleta
//      cliente.deletar();

      }
}
