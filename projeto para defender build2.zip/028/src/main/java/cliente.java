import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class cliente {
    public String nome;
    public String cpf;
    public int idade;

    public void find_one(String cpf){

        String url = "jdbc:mysql://localhost:3306/novobancoteste";
        String usuario = "root";
        String senha = "positivo";

        try {
            // carrega o driver JDBC do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            // estabelece a conexão com o MySQL
            Connection conn = DriverManager.getConnection(url, usuario, senha);                        
            // realiza operações com o banco de dados aqui...
            String slq = "select * from cliente where cpf   = ?";
            // prepara o comando
            PreparedStatement ps = conn.prepareStatement(slq);
            // atribui valores aos parametros

            ps.setString(1, "11111111111");

            // executa o sql e recebe o objeto o tipo ResultSet
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                this.cpf = rs.getString("cpf");
                this.nome = rs.getString("name");
                this.idade = rs.getInt("age");
            }
            
            // fecha a conexão
            conn.close();

        } catch (ClassNotFoundException e) {
            System.out.println("Não foi possível carregar o driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
            e.printStackTrace();
        }
    }
    
    //metodo salvar
    public void salvar() {
        String url = "jdbc:mysql://localhost:3306/novobancoteste";
        String usuario = "root";
        String senha = "positivo";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, usuario, senha);

            String sql = "SELECT * FROM cliente WHERE cpf = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, this.cpf);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // CPF já existe, realizar o update
                String updateSql = "UPDATE cliente SET name = ?, age = ? WHERE cpf = ?";
                PreparedStatement updatePs = conn.prepareStatement(updateSql);
                updatePs.setString(1, this.nome);
                updatePs.setInt(2, this.idade);
                updatePs.setString(3, this.cpf);
                updatePs.executeUpdate();
                System.out.println("Dados atualizados com sucesso!");
            } else {
                // CPF não existe, realizar a inserção
                String insertSql = "INSERT INTO cliente (cpf, name, age) VALUES (?, ?, ?)";
                PreparedStatement insertPs = conn.prepareStatement(insertSql);
                insertPs.setString(1, this.cpf);
                insertPs.setString(2, this.nome);
                insertPs.setInt(3, this.idade);
                insertPs.executeUpdate();
                System.out.println("Usuário salvo com sucesso!");
            }

            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Não foi possível carregar o driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
            e.printStackTrace();
        }
    }
    
    //metodo delete
    public void deletar() {
        String url = "jdbc:mysql://localhost:3306/novobancoteste";
        String usuario = "root";
        String senha = "positivo";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, usuario, senha);

            String sql = "DELETE FROM cliente WHERE cpf = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, this.cpf);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Cliente excluído com sucesso!");
            } else {
                System.out.println("Cliente não encontrado no banco de dados.");
            }

            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Não foi possível carregar o driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
            e.printStackTrace();
        }
    }
}