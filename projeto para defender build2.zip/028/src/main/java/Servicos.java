import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Servicos {
    public String nome;
	public int id;

    public void salvar() {
        String url = "jdbc:mysql://localhost:3306/novobancoteste";
        String usuario = "root";
        String senha = "positivo";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, usuario, senha);

            String selectSql = "SELECT * FROM servicos WHERE service_id = ?";
            PreparedStatement selectPs = conn.prepareStatement(selectSql);
            selectPs.setInt(1, this.id);

            ResultSet rs = selectPs.executeQuery();

            if (rs.next()) {
                // O serviço já existe, realizar o update
                int id = rs.getInt("service_id");
                String updateSql = "UPDATE servicos SET name = ? WHERE service_id = ?";
                PreparedStatement updatePs = conn.prepareStatement(updateSql);
                updatePs.setString(1, this.nome);
                updatePs.setInt(2, id);
                updatePs.executeUpdate();
                System.out.println("Serviço atualizado com sucesso!");
            } else {
                // O serviço não existe, realizar a inserção
                String insertSql = "INSERT INTO servicos (name) VALUES (?)";
                PreparedStatement insertPs = conn.prepareStatement(insertSql);
                insertPs.setString(1, this.nome);
                insertPs.executeUpdate();
                System.out.println("Serviço salvo com sucesso!");
            }

            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Não foi possível carregar o driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
            e.printStackTrace();
        }
    }

	public void deletar() {
	    String url = "jdbc:mysql://localhost:3306/novobancoteste";
	    String usuario = "root";
	    String senha = "positivo";
	
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection conn = DriverManager.getConnection(url, usuario, senha);
	
	        String deleteSql = "DELETE FROM servicos WHERE service_id = ?";
	        PreparedStatement deletePs = conn.prepareStatement(deleteSql);
	        deletePs.setInt(1, this.id);
	        int rowsAffected = deletePs.executeUpdate();
	
	        if (rowsAffected > 0) {
	            System.out.println("Serviço excluído com sucesso!");
	        } else {
	            System.out.println("Não foi possível excluir o serviço. Verifique se o nome está correto.");
	        }
	
	        conn.close();
	    } catch (ClassNotFoundException e) {
	        System.out.println("Não foi possível carregar o driver JDBC.");
	        e.printStackTrace();
	    } catch (SQLException e) {
	        System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
	        e.printStackTrace();
	    }
	}
}