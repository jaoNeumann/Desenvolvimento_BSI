package abc;
import java.io.FileWriter;

public class cliente {

    private String Cpf;
    public String Nome;
    public String Email;
    public String Tel;

    public void salvar() {
        try {
            String separador = ";";
            FileWriter arquivo = new FileWriter("C:\\\\_src\\java-entrega13-04\\entrega13-04\\src\\cliente.csv", true);
            String linha = this.Nome
                    + separador +
                    this.Cpf
                    + separador +
                    this.Email
                    + separador +
                    this.Tel
                    + System.lineSeparator();

            arquivo.write(linha);
            arquivo.flush();
            arquivo.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    };
}
