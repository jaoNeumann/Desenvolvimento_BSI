package abc;
/*
AUTHOR: JOÃO PEDRO NEUMANN
DATE: 2023-04-13
TITLE: ENTREGA PARA DIA 13/04
*/
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class consome_cliente extends cliente {
    // Metodo grava em arquivo
    public static void main(String[] args) {

        try {
            Scanner input_text = new Scanner(System.in);
            String grava = input_text.nextLine();
            FileReader arq_read = new FileReader("c:\\\\_src\\java-entrega13-04\\entrega13-04\\src\\cliente.csv");
            FileWriter arq = new FileWriter("c:\\\\_src\\java-entrega13-04\\entrega13-04\\src\\cliente.csv", true);
            BufferedReader buf_write = new BufferedReader(arq_read);

            arq.write("Clientes da loja  2023 \n " 
                        + " Data: ___/___/___ \n " 
                        + grava);
            arq.flush();

            String ler = buf_write.readLine();
            while (ler != null) {
                System.out.println(ler);
                ler = buf_write.readLine();
            }

            String op = "";
            cliente pessoa = new cliente();
    
            while (!op.equals("0")) {
                System.out.println("Digite 0 para terminar");
    
                System.out.println("Cpf");
                pessoa.Nome = input_text.nextLine();
                input_text= new Scanner(System.in);

                System.out.println("Nome");
                pessoa.Nome = input_text.nextLine();
                input_text= new Scanner(System.in);

                System.out.println("Email");
                pessoa.Nome = input_text.nextLine();
                input_text= new Scanner(System.in);

                System.out.println("Tel");
                pessoa.Nome = input_text.nextLine();
                input_text= new Scanner(System.in);

    
                pessoa.salvar();
                System.out.println("Deseja continuar? (0 para sair)");
                op = input_text.nextLine();
    
            }

            arq_read.close();
            buf_write.close();
            arq.close();

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Deu ruim patão");
            e.printStackTrace();
        }
    }
}
