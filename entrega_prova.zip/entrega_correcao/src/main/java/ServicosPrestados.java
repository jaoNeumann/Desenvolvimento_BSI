import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServicosPrestados {
    public static int id;
    public static String data;
    public static double valor;
    public Cliente cliente;
    public Servicos servico;
    public Terceiros terceiro;
    
    public ServicosPrestados() {
        cliente = new Cliente();
        servico = new Servicos();
        terceiro = new Terceiros();
        
    }

    // Método salvar
    public void salvar() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        

        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            // Verifique se o objeto já existe
            if (id > 0) {
                // Atualize o registro existente
                String sql = "UPDATE servicos_prestados SET ata = ?, valor = ?, id_cliente = ?, id_prestador = ?, id_servico = ? WHERE id = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, data);
                stmt.setDouble(2, valor);
                stmt.setString(3, cliente.cpf);
                stmt.setInt(4, terceiro.id);
                stmt.setInt(5, servico.id);
                stmt.executeUpdate();
            } else {
                // Crie um novo registro
                String sql = "INSERT INTO servicos_prestados (data, valor, id_cliente, id_prestador, id_servico) VALUES (?, ?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, data);
                stmt.setDouble(2, valor);
                stmt.setString(3, cliente.cpf);
                stmt.setInt(4, terceiro.id);
                stmt.setInt(5, servico.id);
                stmt.executeUpdate();

//                // Obtenha o ID gerado para o novo registro
//                rs = stmt.getGeneratedKeys();
//                if (rs.next()) {
//                    id = rs.getInt(1);
//                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar o serviço prestado.");
            e.printStackTrace();
        } finally {
            // Feche os recursos, como PreparedStatement e ResultSet
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com o banco de dados.");
                e.printStackTrace();
            }
        }
    }

    // Método deletar
    public void deletar() {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String sql = "DELETE FROM servicos_prestados WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Serviço prestado excluído com sucesso!");
            } else {
                System.out.println("Serviço prestado não encontrado no banco de dados.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao deletar o serviço prestado.");
            e.printStackTrace();
        } finally {
            // Feche os recursos, como PreparedStatement e ResultSet
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com o banco de dados.");
                e.printStackTrace();
            }
        }
    }
}
