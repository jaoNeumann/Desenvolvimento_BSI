package hierarquia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Gerente extends Pessoa {
    public double salario;
    public String aniversario;
    public String telefone;
    public String departamento;
    public double gratificacao;
    public boolean ativo;
    public boolean situacao;
    
    public Gerente(String cpf, String nome, String email, double salario, String aniversario, String telefone, String departamento, double gratificacao, boolean ativo, boolean situacao) {
        super(cpf, nome, email);
        this.salario = salario;
        this.aniversario = aniversario;
        this.telefone = telefone;
        this.departamento = departamento;
        this.gratificacao = gratificacao;        

    }

    @Override
    public boolean save() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "INSERT INTO gerente (cpf, nome, email, salario, aniversario, telefone, departamento, gratificacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            statement.setString(2, nome);
            statement.setString(3, email);
            statement.setDouble(4, salario);
            statement.setString(5, aniversario);
            statement.setString(6, telefone);
            statement.setString(7, departamento);
            statement.setDouble(8, gratificacao);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean delete() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "DELETE FROM gerente WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean find() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "SELECT * FROM gerente WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Preencha os atributos do gerente com os valores do ResultSet
                cpf = resultSet.getString("cpf");
                nome = resultSet.getString("nome");
                email = resultSet.getString("email");
                salario = resultSet.getDouble("salario");
                aniversario = resultSet.getString("aniversario");
                telefone = resultSet.getString("telefone");
                departamento = resultSet.getString("departamento");
                gratificacao = resultSet.getDouble("gratificacao");
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    public double calcularBonus() {
        return salario * 0.3; // Calcula o bônus como 30% do salário do gerente
    }
}
