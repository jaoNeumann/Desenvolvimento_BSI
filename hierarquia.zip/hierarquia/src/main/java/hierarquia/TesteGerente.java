package hierarquia;

public class TesteGerente {
    public static void main(String[] args) {
        // Criando um objeto Gerente
        Gerente gerente = new Gerente("12345678901", "João Silva", "joao@example.com", 5000.0, "1990-01-01", "999999999", "Departamento A", 1000.0, false, false);

        // Salvando o gerente no banco de dados
        if (gerente.save()) {
            System.out.println("Gerente salvo com sucesso!");
        } else {
            System.out.println("Erro ao salvar gerente.");
        }

        // Calculando o bônus do gerente
//        double bonus = gerente.calcularBonus();
//        System.out.println("Bônus do gerente: R$" + bonus);
//
//        // Buscando o gerente no banco de dados
//        if (gerente.find()) {
//            System.out.println("Gerente encontrado: " + gerente.nome);
//        } else {
//            System.out.println("Gerente não encontrado.");
//        }

        // Deletando o gerente do banco de dados
//        if (gerente.delete()) {
//            System.out.println("Gerente deletado com sucesso!");
//        } else {
//            System.out.println("Erro ao deletar gerente.");
//        }
    }
}

