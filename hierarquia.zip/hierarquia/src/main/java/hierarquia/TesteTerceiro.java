package hierarquia;

public class TesteTerceiro {
    public static void main(String[] args) {
        // Criando um objeto Terceiro
        Terceiro terceiro = new Terceiro("12345678901", "Maria Santos", "maria@example.com", false, null);

        // Salvando o terceiro no banco de dados
//        if (terceiro.save()) {
//            System.out.println("Terceiro salvo com sucesso!");
//        } else {
//            System.out.println("Erro ao salvar terceiro.");
//        }

        // Inativando o terceiro
        String inativado = terceiro.inativar();
        if (inativado == "ativo") {
            System.out.println("Terceiro inativado com sucesso!");
        } else {
            System.out.println("Erro ao inativar terceiro.");
        }

        // Encerrando o contrato do terceiro
//        boolean contratoEncerrado = terceiro.encerrarContrato();
//        if (contratoEncerrado) {
//            System.out.println("Contrato do terceiro encerrado com sucesso!");
//        } else {
//            System.out.println("Erro ao encerrar contrato do terceiro.");
//        }

        // Buscando o terceiro no banco de dados
//        if (terceiro.find()) {
//            System.out.println("Terceiro encontrado: " + terceiro.nome);
//        } else {
//            System.out.println("Terceiro não encontrado.");
//        }

        // Deletando o terceiro do banco de dados
//        if (terceiro.delete()) {
//            System.out.println("Terceiro deletado com sucesso!");
//        } else {
//            System.out.println("Erro ao deletar terceiro.");
//        }
    }
}
