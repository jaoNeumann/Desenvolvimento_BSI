package hierarquia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Terceiro extends Pessoa {
	
    public boolean ativo;
    public String situacao;
    
	public Terceiro(String cpf, String nome, String email, boolean ativo, String situacao) {
        super(cpf, nome, email);
        this.ativo = ativo;
        this.situacao = situacao;
    }

    @Override
    public boolean save() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "INSERT INTO terceiro (cpf, nome, email) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            statement.setString(2, nome);
            statement.setString(3, email);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean delete() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "DELETE FROM terceiro WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean find() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "SELECT * FROM terceiro WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Preencha os atributos do terceiro com os valores do ResultSet
                cpf = resultSet.getString("cpf");
                nome = resultSet.getString("nome");
                email = resultSet.getString("email");
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    public String inativar() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "UPDATE terceiro SET ativo = !ativo WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                ativo = !ativo; // Inverte o valor de ativo
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return "encerrado";
    }

    public boolean encerrarContrato() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "UPDATE terceiro SET situacao = 'encerrado' WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                situacao = "encerrado";
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

}
