package hierarquia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Funcionario extends Pessoa {
    public double salario;
    public String aniversario;
    public String telefone;
    public String departamento;

    public Funcionario(String cpf, String nome, String email, double salario, String aniversario, String telefone, String departamento) {
        super(cpf, nome, email);
        this.salario = salario;
        this.aniversario = aniversario;
        this.telefone = telefone;
        this.departamento = departamento;
    }

    @Override
    public boolean save() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "INSERT INTO funcionario (cpf, nome, email, salario, aniversario, telefone, departamento) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            statement.setString(2, nome);
            statement.setString(3, email);
            statement.setDouble(4, salario);
            statement.setString(5, aniversario);
            statement.setString(6, telefone);
            statement.setString(7, departamento);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean delete() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "DELETE FROM funcionario WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }

    @Override
    public boolean find() {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        try {
            String query = "SELECT * FROM funcionario WHERE cpf = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, cpf);
            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Preencha os atributos do funcionário com os valores do ResultSet
                cpf = resultSet.getString("cpf");
                nome = resultSet.getString("nome");
                email = resultSet.getString("email");
                salario = resultSet.getDouble("salario");
                aniversario = resultSet.getString("aniversario");
                telefone = resultSet.getString("telefone");
                departamento = resultSet.getString("departamento");
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.getInstance().closeConnection(connection);
        }
        return false;
    }
}
