package hierarquia;

public class Pessoa {
    public String cpf;
    public String nome;
    public String email;

    public Pessoa(String cpf, String nome, String email) {
        this.cpf = cpf;
        this.nome = nome;
        this.email = email;
    }

    public boolean save() {
        // Lógica para salvar a pessoa no banco de dados
        // Implemente aqui a lógica específica para salvar uma pessoa
        return true;
    }

    public boolean delete() {
        // Lógica para deletar a pessoa do banco de dados
        // Implemente aqui a lógica específica para deletar uma pessoa
        return true;
    }

    public boolean find() {
        // Lógica para encontrar a pessoa no banco de dados
        // Implemente aqui a lógica específica para encontrar uma pessoa
        return true;
    }
}