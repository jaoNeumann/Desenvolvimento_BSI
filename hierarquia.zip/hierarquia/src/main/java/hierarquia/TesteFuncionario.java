package hierarquia;

public class TesteFuncionario {
    public static void main(String[] args) {
        // Teste do funcionário
        Funcionario funcionario = new Funcionario("11111111111", "João", "joao@teste.com", 5000.00, "1990-05-10", "123456789", "Vendas");

        // Teste do método save()
        boolean saveResult = funcionario.save();
        if (saveResult) {
            System.out.println("Funcionário salvo com sucesso.");
        } else {
            System.out.println("Erro ao salvar funcionário.");
        }

        // Teste do método find()
//        boolean findResult = funcionario.find();
//        if (findResult) {
//            System.out.println("Funcionário encontrado: " + funcionario);
//        } else {
//            System.out.println("Funcionário não encontrado.");
//        }

        // Teste do método delete()
//        boolean deleteResult = funcionario.delete();
//        if (deleteResult) {
//            System.out.println("Funcionário excluído com sucesso.");
//        } else {
//            System.out.println("Erro ao excluir funcionário.");
//        }
    }
}
