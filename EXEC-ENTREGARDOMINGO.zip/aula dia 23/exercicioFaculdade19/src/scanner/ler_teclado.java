package scanner;

import java.util.Scanner;

public class ler_teclado {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome = "";
        System.out.println("Insere teu nome: ");
        nome = teclado.nextLine();

        System.out.println("nome:  " + nome);
        
    }
}
