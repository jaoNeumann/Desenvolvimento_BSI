package exercicioFaculdade;

public class aluno{
	public String Cpf;
	public String Matricula;
	public String Nome;
	public String Email;
}