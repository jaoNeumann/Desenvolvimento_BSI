package exercicioFaculdade;

public class consome_turma {
    public static void main(String[] args) {

    Professor prof = new Professor();
    aluno alu = new aluno();
    turma tur = new turma();

    //populando professor
    prof.Cpf = "12345678912";
    prof.Nome = "Escobar";
    prof.Matricula = "0055";
    prof.Email = "Escobar@email.com";

    tur.Codigo=1;
    tur.Professor = prof;
    //construção do aluno
    alu = new aluno();
    alu.Nome = "Joao";
    alu.Cpf = "08391945689";
    alu.Matricula = "2121";
    alu.Email = "Joao@email.com";

    tur.Alunos.add(alu);

    alu = new aluno();
    alu.Nome = "caio";
    alu.Cpf = "0134589557";
    alu.Matricula = "2583";
    alu.Email = "Caio@email.com";

    tur.Alunos.add(alu);

    alu = new aluno();
    alu.Nome = "Emily";
    alu.Cpf = "06987563201";
    alu.Matricula = "7893";
    alu.Email = "Emily@email.com";

    tur.Alunos.add(alu);

    // System.out.println(tur.getAlunos());
    // System.out.println(tur.Professor.Nome);

    for(int i = 0; i < tur.Alunos.size(); i++){
        System.out.println(tur.Alunos.get(i).Nome);
    }



}
}

