package exercicioFaculdade;

public class Professor {
	public String Cpf;
	public String Matricula;
	public String Nome;
	public String Email;
	//construtor padrao
	Professor(){}


	//construtor com argumentos
	public Professor(String Cpf, String Matricula, String Nome, String Email){
		this.Cpf = Cpf;
		this.Matricula = Matricula;
		this.Nome = Nome;
		this.Email = Email;
	}


}