package gerenciamentoDeContaBancaria;

public class Conta {

    public int Numero;
    public String Tipo;
    private double Saldo;

    public Conta() {
    }

    // Getter
    public double getSaldo() {
        return this.Saldo;
    }

    // Setter
    public double depositar(double valor_deposito) {

        this.Saldo += valor_deposito;

        return this.Saldo;
    }

    public boolean sacar(double valor_saque) {

        if (valor_saque > this.Saldo || valor_saque <= 0) {
            return false;
        } else {
            this.Saldo -= valor_saque;
            return true;
        }
    }
}
