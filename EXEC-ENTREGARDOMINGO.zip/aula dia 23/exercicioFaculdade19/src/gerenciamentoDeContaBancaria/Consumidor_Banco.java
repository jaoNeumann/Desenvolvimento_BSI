package gerenciamentoDeContaBancaria;

import java.util.ArrayList;
import java.util.Scanner;

public class Consumidor_Banco {

    public static void main(String[] args) {
        // banco
        Banco ban = new Banco();
        Cliente cli = new Cliente();
        Conta con = new Conta();

        int option = 1;

        while (option != 0) {
            System.out.println("informe a opção");
            System.out.println("\n1 para criar usuário");
            System.out.println("2 para fechar a aplicação");

            Scanner teclado = new Scanner(System.in);
            option = teclado.nextInt();
            switch (option) {
                case 1:
                    Scanner teclado_cpf = new Scanner(System.in);
                    System.out.println("\n informe CPF ");
                    cli.Cpf = teclado_cpf.nextLine();

                    Scanner teclado_name = new Scanner(System.in);
                    System.out.println("\n Informe Nome ");
                    cli.Nome = teclado_name.nextLine();

                    Scanner teclado_mail = new Scanner(System.in);
                    System.out.println("\n Informe Email ");
                    cli.Email = teclado_mail.nextLine();

                    System.out.println("Agora criaremos sua conta \n");
                    System.out.println("Informe o nº da conta: ");

                    Scanner teclado_num = new Scanner(System.in);
                    con.Numero = teclado_num.nextInt();

                    Scanner teclado_type = new Scanner(System.in);
                    System.out.println("\n Informe o tipo da conta ");
                    con.Tipo = teclado_type.nextLine();

                    System.out.println(
                            "infos do usuário \n CPF: " + cli.Cpf
                                    +
                                    "\n Nome: " + cli.Nome
                                    +
                                    "\n Email: " + cli.Email
                                    +
                                    "\n Conta Nº: " + con.Numero
                                    +
                                    "\n Tipo de conta: " + con.Tipo
                                    + "");

                    ban.addClientes(cli);

                    int receba = 100;
                    while (receba != 5) {

                        System.out.println("\n \nBem vindo a sua nova conta, Seu saldo é de R$: " + con.getSaldo());
                        System.out.println("Selecione: \n 9 - sacar \n 8 - depositar \n 5 - sair");
                        Scanner teclado_receba = new Scanner(System.in);
                        receba = teclado_receba.nextInt();
                        switch (receba) {
                            case 9:

                                System.out.println("Qual valor deseja sacar?");

                                Scanner teclado_saque = new Scanner(System.in);
                                double valor_saque = teclado_saque.nextDouble();
                                con.sacar(valor_saque);
                                break;
                            case 8:
                                System.out.println("Qual valor deseja Depositar?");

                                Scanner teclado_deposito = new Scanner(System.in);
                                double valor_deposito = teclado_deposito.nextDouble();
                                con.depositar(valor_deposito);
                                System.out.println("\nDepósito realizado, Seu saldo é de R$: " + con.getSaldo());

                                break;

                            default:
                                break;
                        }
                    }

                    break;
                case 2:
                    System.out.println("\nVocê saiu.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("opção invalida, tente novamente");
                    break;
            }
        }

    }
}
