package gerenciamentoDeContaBancaria;

import java.util.ArrayList;

public class Cliente {

	public String Cpf;
	public String Nome;
	public String Email;
	public ArrayList<Conta> Cliente_contas = new ArrayList<Conta>();

	// construtor cliente
	public Cliente() {
	}
	
	// public addConta()
	// }
}