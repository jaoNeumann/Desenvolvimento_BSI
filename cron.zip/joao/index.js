/*
Author: João Pedro
Date: 03/04/23
*/
const express = require('express');
const cron = require("node-cron");
const app = express();
const PORT = 3003;
app.listen(PORT, ()=>{
    console.log(`THE PORT IS ${PORT}`);
});


let data = Date();

// let show_data = 

// var formatter = new StringMask("(000) 000-0000", { reverse: true });
app.get('/', (req,res)=>{
    res.send("ola");
});

app.get('/hora', (req,res)=>{
    cron.schedule("*/15 * * * *", () => console.log(`A data atual é ${data}`));
    // res.send(`A data atual é ${data}`));
});
