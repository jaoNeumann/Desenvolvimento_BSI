import com.sun.jdi.connect.spi.Connection;

public class consumidor_x {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Servicos servico = new Servicos();
		ServicosPrestados servicos_prestados = new ServicosPrestados();

		
		servicos_prestados.id = 1;
		servicos_prestados.data = "10/02/23"; 
		servicos_prestados.valor = 10000;
		servicos_prestados.cliente.cpf = "11111111111";
		servicos_prestados.servico.id = 101;
		
	
		servicos_prestados.salvar();
		
		System.out.println(
			"id do serviço: " +
			servicos_prestados.id +
			" | Código do sercviço: " +
			servicos_prestados.servico.id +
			" | Cliente: " +
			servicos_prestados.cliente.nome
		);
	
//		servico.nome = "Serviço C";
//		servico.excluir();
	
	}
}