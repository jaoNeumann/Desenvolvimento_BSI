import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionSingleton {
    private static Connection connection;

    private ConnectionSingleton() {
        // Construtor privado → evitar instanciação externa
    }

    public static Connection getConnection() {
        if (connection == null) {
            synchronized (ConnectionSingleton.class) {
                if (connection == null) {
                    try {
                        String url = "jdbc:mysql://localhost:3306/novobancoteste";
                        String username = "root";
                        String password = "positivo";

                        Class.forName("com.mysql.cj.jdbc.Driver");

                        // Estabelece conexão
                        connection = DriverManager.getConnection(url, username, password);
                    } catch (ClassNotFoundException | SQLException e) {
                        System.out.println("Não foi possível estabelecer a conexão com o MySQL.");
                        e.printStackTrace();
                    }
                }
            }
        }
        return connection;
    }
}
