import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServicosPrestados {
    public int id;
    public String data;
    public double valor;
    Cliente cliente = new Cliente(); // id → id_cliente
    Servicos servico = new Servicos(); // id → service_id
	//Terceiro idPrstador = new Terceiro(); // id → services_providers_id
    Connection conn;

    // Métodos

    public void salvar() {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionSingleton.getConnection();

            // Verifique se o objeto já existe
            	if (this.id>0) {
                // Atualize o registro existente
                String sql = "UPDATE servicos_prestados SET data = ?, valor = ?, id_cliente = ?, id_servico = ? WHERE id = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, data);
                stmt.setDouble(2, valor);
                stmt.setString(3, cliente.cpf);
                stmt.setInt(4, servico.id);
                stmt.setInt(5, id);
                stmt.executeUpdate();
            } else {
                // Crie um novo registro
                String sql = "INSERT INTO servicos_prestados (data, valor, id_cliente, id_servico) VALUES (?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, data);
                stmt.setDouble(2, valor);
                stmt.setString(3, cliente.cpf);
                stmt.setInt(4, servico.id);
                stmt.executeUpdate();

                // Obtenha o ID gerado para o novo registro
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    id = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
       }
    }
}
