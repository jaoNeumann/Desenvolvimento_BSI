/*
Author: João Pedro
Date: 06/04/23
*/
const express = require('express');
const app = express();
const controlador = require('./controlador.js');

// recebe module.exports
controlador.salvar;
// Permitir uso de JSON
app.use(express.json());

app.get('/', (req,res)=>{
    res.send("Pagina certa! endereço = > / < ");
});

app.get('/user', (req,res)=>{
    const user = req.body; // Criando o objeto user a partir da requisição
    res.send(controlador.salvar(user)); // Enviando objeto user para o metodo salvar
});

// sempre no final do index!!!
const PORT = 3003;
app.listen(PORT, ()=>{
    console.log(`THE PORT IS ${PORT}`);
});