function salvar(user){
    // No futuro salva no banco
    console.log('deu boa');
    return 'deu boa 2';
}

// EXPORTA o metodo que por padrão é criado private
module.exports = {    
    salvar
};
