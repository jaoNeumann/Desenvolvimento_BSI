package polimorfismo;

public class Bacharelado extends Curso {
    public Bacharelado(String nomeCurso, double valorParcela) {
        super(nomeCurso, valorParcela);
    }
}