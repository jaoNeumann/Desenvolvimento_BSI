package polimorfismo;

public abstract class Curso implements InterCurso {
    protected String nomeCurso;
    protected double valorParcela;

    public Curso(String nomeCurso, double valorParcela) {
        this.nomeCurso = nomeCurso;
        this.valorParcela = valorParcela;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public double getValorParcela() {
        return valorParcela;
    }
}
