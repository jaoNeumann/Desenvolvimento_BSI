package polimorfismo;

public class BachareladoLaboratorio extends Curso {
    private double custoAdicionalLaboratorio;

    public BachareladoLaboratorio(String nomeCurso, double custoDoCurso, double custoAdicionalLaboratorio) {
        super(nomeCurso, custoDoCurso);
        this.custoAdicionalLaboratorio = custoAdicionalLaboratorio;
    }

    public double getValorParcela() {
        return valorParcela + custoAdicionalLaboratorio;
    }
}