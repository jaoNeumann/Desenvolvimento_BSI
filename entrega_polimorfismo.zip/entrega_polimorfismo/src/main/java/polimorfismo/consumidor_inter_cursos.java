package polimorfismo;

public class consumidor_inter_cursos {
    public static void main(String[] args) {
        Estudante aluno = new Estudante();

        Bacharelado bsi = new Bacharelado("BSI", 2300.00);
        BachareladoLaboratorio odonto = new BachareladoLaboratorio("Odonto", 5000.99, 1800.99);

        aluno.addCurso(bsi);
        aluno.addCurso(odonto);

        System.out.println("O Valor mensal é de: R$" + aluno.getValorTotal()); // Imprime a soma das parcelas de cada curso adicionado em aluno.cursos
    }
}