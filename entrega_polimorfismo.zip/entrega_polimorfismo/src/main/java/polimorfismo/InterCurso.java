package polimorfismo;

public interface InterCurso {
    double getValorParcela();
    String getNomeCurso();
}