package polimorfismo;

import java.util.ArrayList;
import java.util.List;

public class Estudante {
    public List<InterCurso> cursos;

    public Estudante() {
        cursos = new ArrayList<>();
    }

    public void addCurso(InterCurso curso) {
        cursos.add(curso);
    }

    public double getValorTotal() {
        double valorTotal = 0.0;
        for (InterCurso curso : cursos) {
            valorTotal += curso.getValorParcela();
        }
        return valorTotal;
    }
}