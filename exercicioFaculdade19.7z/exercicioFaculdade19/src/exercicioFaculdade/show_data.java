// package exercicioFaculdade;

// public class show_data {

// 	public static void main(String[] args) {
// 		// TODO Auto-generated method stub
// 		disciplinas.nome.add("Joao");
		
		
// 		System.out.println(disciplinas.nome);
// 	}

// }
