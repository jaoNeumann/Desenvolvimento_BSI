package exercicioFaculdade;

import java.util.ArrayList;

public class curso {
	public double duracao;
	
	ArrayList<String> disciplinas = new ArrayList<String>();
	
}
