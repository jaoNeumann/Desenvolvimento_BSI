/**
 * 
 */
/**
 * @author Aluno
 *
 */
module exercicioFaculdade {
}