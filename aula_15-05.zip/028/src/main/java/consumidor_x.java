import com.sun.jdi.connect.spi.Connection;

public class consumidor_x {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		user u = user.getInstance();
//		u.id = 1;
//		u.nome = "purga";
//		
//		System.out.println("Nome do usuario 1 = " + u.nome);
//		
//		user u2 = user.getInstance();
//		System.out.println("Nome do usuario 2 = " + u2.nome);
		database conn = new database();
		conn.url = "www.google.com.br";
		conn.user = "joaoMonoBola";
		conn.getPass();
		
		
		
		
	
	}
}

