
public class user {
	public int id;
	static String nome;	
	static user instance;
	
	//Passo 1: o construtor padrão deve ser inacessível pelos consumidores
	private user(){
	}
	
	static user getInstance() {
		if(instance == null) {
		instance = new user(); //controi um objeto do tipo user
		}
		return instance;
	}
}

