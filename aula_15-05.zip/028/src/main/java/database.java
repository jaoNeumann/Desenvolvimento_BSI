
public class database {

	public String url;
	public String user;
	private String password;
	static database connection;
	
	
	public database getInstance() {
		if(connection == null) {
			connection = new database();
		}
		return connection;
	}
	
	  public String getPass() {
	        return this.password;
	    }
	}
