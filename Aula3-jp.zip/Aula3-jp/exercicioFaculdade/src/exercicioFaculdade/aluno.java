package exercicioFaculdade;

public class aluno extends pessoa{
	curso cursoAluno = new curso();
	
}