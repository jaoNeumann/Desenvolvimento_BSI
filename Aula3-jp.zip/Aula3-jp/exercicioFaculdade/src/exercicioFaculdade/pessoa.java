package exercicioFaculdade;

public class pessoa {
	public String nome;
	public String sorbenome;
	public String cpf;
	public String situacao;
	public String matricula;
	public int idade;
	
}
