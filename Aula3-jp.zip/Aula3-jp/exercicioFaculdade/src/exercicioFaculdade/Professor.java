package exercicioFaculdade;

public class Professor {
	private double salario;
//	public disciplina disciplinas;
	
}