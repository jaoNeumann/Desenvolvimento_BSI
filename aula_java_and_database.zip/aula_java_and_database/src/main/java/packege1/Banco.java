package packege1;

import java.util.ArrayList;

public class Banco {
	public int id;
	public String Nome_do_banco;
	public ArrayList<Cliente> clientes = new ArrayList<Cliente>();

}
