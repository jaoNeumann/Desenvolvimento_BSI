/*
Primeiro programa em Node
Autor: João, o Belissimo
Data? 0304/2023
*/

// Instanciar o Express
const express = require('express');
const app = express();

// Cria endpoint http://localhost:porta/
app.get('/', (req,res) => {
    res.send("Opa to na area");
});

// No final do index.js, ativar o server (porta)
const PORT = 3009;
app.listen(PORT, ()=>{
    console.log(`Servidor rodando na porta ${PORT}`);
});

app.post( '/req=sum', (req,res) => {
    const a = 1;
    const b = 2;
    const sum = a + b;
    res = sum;
});