import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Servicos {
    public String nome;
    public int id;
    Connection conn;

    // Método salvar
    public void salvar() {
        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String selectSql = "SELECT * FROM servicos WHERE service_id = ?";
            PreparedStatement selectPs = conn.prepareStatement(selectSql);
            selectPs.setInt(1, this.id);

            ResultSet rs = selectPs.executeQuery();

            if (rs.next()) {
                // O serviço já existe, realizar o update
                int id = rs.getInt("service_id");
                String updateSql = "UPDATE servicos SET name = ? WHERE service_id = ?";
                PreparedStatement updatePs = conn.prepareStatement(updateSql);
                updatePs.setString(1, this.nome);
                updatePs.setInt(2, id);
                updatePs.executeUpdate();
                System.out.println("Serviço atualizado com sucesso!");
            } else {
                // O serviço não existe, realizar a inserção
                String insertSql = "INSERT INTO servicos (name) VALUES (?)";
                PreparedStatement insertPs = conn.prepareStatement(insertSql);
                insertPs.setString(1, this.nome);
                insertPs.executeUpdate();
                System.out.println("Serviço salvo com sucesso!");
            }

            // Não é necessário fechar a conexão, já que o singleton cuida disso

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método deletar
    public void deletar() {
        try {
            // Obtenha a instância de conexão da classe de conexão singleton
            conn = ConnectionSingleton.getConnection();

            String deleteSql = "DELETE FROM servicos WHERE service_id = ?";
            PreparedStatement deletePs = conn.prepareStatement(deleteSql);
            deletePs.setInt(1, this.id);
            int rowsAffected = deletePs.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Serviço excluído com sucesso!");
            } else {
                System.out.println("Não foi possível excluir o serviço. Verifique se o nome está correto.");
            }

            // Não é necessário fechar a conexão, já que o singleton cuida disso

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
