package exercicioEntregaDia16;

public class consumidor_estante {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		livro l;
		estante e = new estante();
		
		l = new livro();
		l.Titulo = "Biblia";
		l.Autor = "Diversos";
		l.Ano = "0";
		
		e.Prateleira.add(l);
		
		l = new livro();
		l.Titulo = "Tora";
		l.Autor = "Diversos";
		l.Ano = "0";
		
		e.Prateleira.add(l);
		
		l = new livro();
		l.Titulo = "Alcorão";
		l.Autor = "Diversos";
		l.Ano = "0";
		
		e.Prateleira.add(l);
		
		System.out.println(e.listar_livros());
		
		
	}

}
