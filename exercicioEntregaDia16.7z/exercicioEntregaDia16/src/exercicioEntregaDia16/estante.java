package exercicioEntregaDia16;

import java.util.ArrayList;


public class estante {
	
		public ArrayList<livro> Prateleira = new ArrayList<livro>();
		 
			public ArrayList<String> listar_livros() {
				
				ArrayList<String> titulos = new ArrayList<String>();
				
				for(int i = 0; i < this.Prateleira.size(); i++)
					titulos.add(this.Prateleira.get(i).Titulo);
				
					return(titulos);
					
			}

}
