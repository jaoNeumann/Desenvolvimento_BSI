package exercicioEntregaDia16;

public class livro {
	public String Autor;
	public String Titulo;
	public String Ano;
}