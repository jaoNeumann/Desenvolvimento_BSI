import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class GravaArq {

    public static void main(String[] args) {
        try {
            Scanner input_text = new Scanner(System.in);
            String grava = input_text.nextLine();
            FileWriter arq = new FileWriter("C:/_src/teste01.txt", true);
            FileReader arq_read = new FileReader("C:/_src/teste01.txt");
            BufferedReader read_this = new BufferedReader(arq_read);

            arq.write(grava);
            arq.flush();

            String leia = read_this.readLine();
            while (leia != null) {
                System.out.println(leia);
                leia = read_this.readLine();
            }

            arq.close();
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Deu ruim");
            e.printStackTrace();
        }
    }

}
