package exercicioFaculdade;

import java.util.ArrayList;

public class turma {
	public int codigo;
    public Professor prof = new Professor();

    public ArrayList<aluno> alunos = new ArrayList<aluno>();

    public ArrayList<String> busca_aluno() {
    
        ArrayList<String> alunos = new ArrayList<String>();
        
        for(int i = 0; i < this.alunos.size(); i++)
            alunos.add(this.alunos.get(i).Nome);
        
        return(alunos);
            

    }
}
