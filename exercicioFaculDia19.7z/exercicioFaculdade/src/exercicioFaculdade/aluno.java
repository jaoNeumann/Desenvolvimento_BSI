package exercicioFaculdade;

public class aluno{
	public String Nome;
	public String Cpf;
	public String Matricula;
	public String Email;
}