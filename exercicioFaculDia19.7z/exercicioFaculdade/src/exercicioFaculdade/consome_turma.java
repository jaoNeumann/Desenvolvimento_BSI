package exercicioFaculdade;

public class consome_turma {

    public static void main(String[] args) {

    aluno alu;
    Professor prof = new Professor();
    turma tur = new turma();

    prof.Nome = "Escobar";
    prof.Cpf = "12345678912";
    prof.Matricula = "0055";
    prof.Email = "Escobar@email.com";

    tur.prof = prof;

    
    alu = new aluno();
    alu.Nome = "Joao";
    alu.Cpf = "08391945689";
    alu.Matricula = "2121";
    alu.Email = "Joao@email.com";

    tur.alunos.add(alu);

    alu = new aluno();
    alu.Nome = "caio";
    alu.Cpf = "0134589557";
    alu.Matricula = "2583";
    alu.Email = "Caio@email.com";

    tur.alunos.add(alu);

    alu = new aluno();
    alu.Nome = "Emily";
    alu.Cpf = "06987563201";
    alu.Matricula = "7893";
    alu.Email = "Emily@email.com";

    tur.alunos.add(alu);

    System.out.println(tur.busca_aluno());
    System.out.println(tur.prof.Nome);
}
}
