package exercicioFaculdade;

import java.util.ArrayList;

public class disciplinas {
	ArrayList<String> nome = new ArrayList<String>();
	

}