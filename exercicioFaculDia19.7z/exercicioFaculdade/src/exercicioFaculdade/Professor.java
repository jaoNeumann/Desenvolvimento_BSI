package exercicioFaculdade;

public class Professor {
	public String Nome;
	public String Cpf;
	public String Matricula;
	public String Email;
}